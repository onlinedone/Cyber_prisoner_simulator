# Looking for setting snapshots or chat backups?

Individual user backups are now located in the data directory.

Example for the default user under default data root:

/data/default-user/backups

This folder remains for historical purposes only.
