# kokoro-js

* Author: hexgrad
* NPM: <https://www.npmjs.com/package/kokoro-js>
* Version: 1.2.0
* License: Apache-2.0

Last updated: 2025-03-10
