import { SlashCommandExecutor } from './SlashCommandExecutor.js';

export class SlashCommandBreakPoint extends SlashCommandExecutor {}
