export class SlashCommandBreakController {
    /**@type {boolean} */ isBreak = false;

    break() {
        this.isBreak = true;
    }
}
